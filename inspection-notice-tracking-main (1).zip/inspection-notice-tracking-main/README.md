# NCR Dashboard – Y2026

Two-tab dashboard with JWT authentication, reading live from Google Drive.

## Tabs
- **Inspection Notice** — `LIST` sheet (NCR tracking by product/process/result)
- **Confirmed NCR** — `Quality Status (HQ)` sheet (defect rate trends, process breakdown)

## Structure
```
ncr-dashboard/
├── index.html
├── package.json
├── vite.config.js
├── vercel.json
├── api/
│   ├── auth.js    ← POST /api/auth   — verify password, return signed JWT (8h)
│   └── data.js    ← GET  /api/data   — JWT-protected Google Drive proxy
└── src/
    ├── main.jsx
    └── App.jsx    ← full dashboard (login + 2 tabs)
```

## Security model
1. User submits password → `POST /api/auth`
2. Server verifies against `ACCESS_PASSWORD` env var (never sent to browser)
3. Server signs JWT with `JWT_SECRET` (HMAC-SHA256), expires in **8 hours**
4. JWT stored in `sessionStorage` (cleared on browser close)
5. Every data request → `GET /api/data` with `Authorization: Bearer <token>`
6. Server verifies JWT signature + expiry before fetching from Google Drive
7. Google Drive is **never** called directly from the browser

## Deploy to Vercel
1. Push to GitHub → Import at vercel.com
2. **Settings → Environment Variables** — add:

| Name | Value |
|------|-------|
| `ACCESS_PASSWORD` | your login password |
| `JWT_SECRET` | random 32+ char string (`openssl rand -hex 32`) |
| `FILE_ID_IN` | `1hyzSfa5tGSdmj_ifC0FqkivGXacxQcta` |
| `FILE_ID_NCR` | `1Pq6lO2YB5zhHGPaEq38c2Wgk8SDGjzao` |

3. Redeploy after adding variables.

## Local dev
```bash
npm install
vercel dev
```
Create `.env.local`:
```
ACCESS_PASSWORD=yourpassword
JWT_SECRET=any_random_32char_string
FILE_ID_IN=1hyzSfa5tGSdmj_ifC0FqkivGXacxQcta
FILE_ID_NCR=1Pq6lO2YB5zhHGPaEq38c2Wgk8SDGjzao
```
