// Auth helpers — JWT stored in sessionStorage, verified server-side on load

const TOKEN_KEY = 'ncr_token'

export function getToken()          { return sessionStorage.getItem(TOKEN_KEY) }
export function saveToken(t)        { sessionStorage.setItem(TOKEN_KEY, t) }
export function clearToken()        { sessionStorage.removeItem(TOKEN_KEY) }

export async function login(password) {
  const r = await fetch('/api/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password }),
  })
  const data = await r.json()
  if (!r.ok) throw new Error(data.error || 'Incorrect password.')
  saveToken(data.token)
  return data.token
}

export async function verifyToken(token) {
  if (!token) return false
  try {
    const r = await fetch('/api/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token }),
    })
    const data = await r.json()
    return data.valid === true
  } catch {
    return false
  }
}
