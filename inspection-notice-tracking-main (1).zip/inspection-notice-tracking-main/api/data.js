// GET /api/data?file=in|ncr — verify JWT, proxy Google Drive xlsx
// ENV: JWT_SECRET, FILE_ID_IN, FILE_ID_NCR

export default async function handler(req, res) {
  const secret = process.env.JWT_SECRET
  if (!secret) return res.status(500).json({ error: 'Server not configured.' })

  // ── Verify JWT from Authorization header ──────────────────────────────────
  const auth  = req.headers['authorization'] || ''
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : ''

  if (!token) return res.status(401).json({ error: 'No token.' })

  try {
    const valid = await verifyJWT(token, secret)
    if (!valid) return res.status(401).json({ error: 'Invalid or expired token.' })
  } catch {
    return res.status(401).json({ error: 'Token error.' })
  }

  // ── Resolve file ID ───────────────────────────────────────────────────────
  const which  = req.query?.file === 'ncr' ? 'ncr' : 'in'
  const fileId = which === 'ncr'
    ? (process.env.FILE_ID_NCR || '1Pq6lO2YB5zhHGPaEq38c2Wgk8SDGjzao')
    : (process.env.FILE_ID_IN  || '1hyzSfa5tGSdmj_ifC0FqkivGXacxQcta')

  // ── Fetch from Google Drive ───────────────────────────────────────────────
  const url = `https://docs.google.com/spreadsheets/d/${fileId}/export?format=xlsx`

  try {
    const r = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
      // 15s timeout via AbortSignal
      signal: AbortSignal.timeout(15000),
    })
    if (!r.ok) return res.status(r.status).json({ error: `Google Drive: HTTP ${r.status}` })

    const buf = await r.arrayBuffer()
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    res.setHeader('Cache-Control', 'private, no-store')
    res.send(Buffer.from(buf))
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
}

// ── JWT verify (HMAC-SHA256, check expiry) ────────────────────────────────────
async function verifyJWT(token, secret) {
  const parts = token.split('.')
  if (parts.length !== 3) return false

  const [header, payload, sig] = parts
  const expected = await hmac(`${header}.${payload}`, secret)
  if (expected !== sig) return false

  const decoded = JSON.parse(atob(payload.replace(/-/g,'+').replace(/_/g,'/')))
  if (decoded.exp && Date.now() / 1000 > decoded.exp) return false

  return true
}

async function hmac(data, secret) {
  const enc = new TextEncoder()
  const key = await crypto.subtle.importKey(
    'raw', enc.encode(secret), { name:'HMAC', hash:'SHA-256' }, false, ['sign'])
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(data))
  return btoa(String.fromCharCode(...new Uint8Array(sig)))
    .replace(/\+/g,'-').replace(/\//g,'_').replace(/=/g,'')
}
