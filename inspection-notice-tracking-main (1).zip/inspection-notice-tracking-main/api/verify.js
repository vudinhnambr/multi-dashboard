// Vercel Serverless Function — verify JWT token
// Called by the frontend before loading data to confirm token is valid & not expired

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()

  const { token } = req.body || {}
  const secret = process.env.JWT_SECRET

  if (!secret) return res.status(500).json({ valid: false, error: 'Server not configured.' })
  if (!token)  return res.status(401).json({ valid: false, error: 'No token.' })

  try {
    const valid = await verifyJWT(token, secret)
    return res.status(valid ? 200 : 401).json({ valid })
  } catch {
    return res.status(401).json({ valid: false })
  }
}

async function verifyJWT(token, secret) {
  const parts = token.split('.')
  if (parts.length !== 3) return false

  const [header, payload, sig] = parts
  const expected = await hmacSha256(`${header}.${payload}`, secret)
  if (expected !== sig) return false   // signature mismatch

  const { exp } = JSON.parse(atob(payload.replace(/-/g,'+').replace(/_/g,'/')))
  if (exp && Date.now() / 1000 > exp) return false  // expired

  return true
}

async function hmacSha256(data, secret) {
  const enc = new TextEncoder()
  const key = await crypto.subtle.importKey(
    'raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  )
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(data))
  return btoa(String.fromCharCode(...new Uint8Array(sig)))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '')
}
