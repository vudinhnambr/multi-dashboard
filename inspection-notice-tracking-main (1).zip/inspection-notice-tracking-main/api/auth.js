// POST /api/auth — verify password, return signed JWT (8h expiry)
// ENV: ACCESS_PASSWORD, JWT_SECRET
//
// Rate limiting: in-memory per IP
//   - Max 5 failed attempts within 15 minutes → locked for 15 minutes
//   - Successful login resets the counter for that IP

const WINDOW_MS   = 15 * 60 * 1000  // 15 minutes
const MAX_FAILS   = 5                // max failed attempts
const LOCKOUT_MS  = 15 * 60 * 1000  // lockout duration

// In-memory store: { ip → { count, firstFail, lockedUntil } }
// Note: resets on every cold start (Vercel serverless), which is acceptable
// for this use-case — persistent storage (KV/Redis) would survive restarts.
const attempts = new Map()

function getIp(req) {
  // Vercel sets x-forwarded-for; fall back to socket address
  const fwd = req.headers['x-forwarded-for']
  return (fwd ? fwd.split(',')[0] : req.socket?.remoteAddress || 'unknown').trim()
}

function checkRateLimit(ip) {
  const now  = Date.now()
  const entry = attempts.get(ip) || { count: 0, firstFail: now, lockedUntil: 0 }

  // Still locked out?
  if (entry.lockedUntil && now < entry.lockedUntil) {
    const secsLeft = Math.ceil((entry.lockedUntil - now) / 1000)
    return { blocked: true, secsLeft }
  }

  // Reset window if it has expired
  if (now - entry.firstFail > WINDOW_MS) {
    attempts.set(ip, { count: 0, firstFail: now, lockedUntil: 0 })
    return { blocked: false }
  }

  return { blocked: false }
}

function recordFailure(ip) {
  const now   = Date.now()
  const entry = attempts.get(ip) || { count: 0, firstFail: now, lockedUntil: 0 }

  // If window expired, restart counter
  if (now - entry.firstFail > WINDOW_MS) {
    attempts.set(ip, { count: 1, firstFail: now, lockedUntil: 0 })
    return
  }

  entry.count++
  if (entry.count >= MAX_FAILS) {
    entry.lockedUntil = now + LOCKOUT_MS
  }
  attempts.set(ip, entry)
}

function recordSuccess(ip) {
  attempts.delete(ip)
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()

  const ip = getIp(req)

  // ── Rate limit check ───────────────────────────────────────────────────────
  const { blocked, secsLeft } = checkRateLimit(ip)
  if (blocked) {
    const mins = Math.ceil(secsLeft / 60)
    return res.status(429).json({
      error: `Too many failed attempts. Try again in ${mins} minute${mins !== 1 ? 's' : ''}.`
    })
  }

  // ── Config check ───────────────────────────────────────────────────────────
  const { password } = req.body || {}
  const expected = process.env.ACCESS_PASSWORD
  const secret   = process.env.JWT_SECRET

  if (!expected || !secret)
    return res.status(500).json({ error: 'Server not configured.' })

  // ── Constant-time delay (slows brute force even before lockout) ────────────
  await new Promise(r => setTimeout(r, 400))

  // ── Password check ─────────────────────────────────────────────────────────
  if (password !== expected) {
    recordFailure(ip)

    const entry    = attempts.get(ip) || { count: 0 }
    const remaining = Math.max(0, MAX_FAILS - entry.count)

    return res.status(401).json({
      error: remaining > 0
        ? `Incorrect password. ${remaining} attempt${remaining !== 1 ? 's' : ''} remaining.`
        : `Too many failed attempts. Try again in ${Math.ceil(LOCKOUT_MS / 60000)} minutes.`
    })
  }

  // ── Success — issue JWT ────────────────────────────────────────────────────
  recordSuccess(ip)

  const header  = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))
  const payload = b64url(JSON.stringify({
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + 60 * 60 * 8, // 8 hours
  }))
  const sig   = await hmac(`${header}.${payload}`, secret)
  const token = `${header}.${payload}.${sig}`

  return res.status(200).json({ token })
}

function b64url(str) {
  return btoa(str).replace(/\+/g,'-').replace(/\//g,'_').replace(/=/g,'')
}

async function hmac(data, secret) {
  const enc = new TextEncoder()
  const key = await crypto.subtle.importKey(
    'raw', enc.encode(secret), { name:'HMAC', hash:'SHA-256' }, false, ['sign'])
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(data))
  return btoa(String.fromCharCode(...new Uint8Array(sig)))
    .replace(/\+/g,'-').replace(/\//g,'_').replace(/=/g,'')
}
